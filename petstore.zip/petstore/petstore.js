
/**
 * This function should calculate the total amount of pet food that should be
 * ordered for the upcoming week.
 * @param numAnimals the number of animals in the store
 * @param avgFood the average amount of food (in kilograms) eaten by the animals
 * 				each week
 * @return the total amount of pet food that should be ordered for the upcoming
 * 				 week, or -1 if the numAnimals or avgFood are less than 0 or non-numeric
 */
function calculateFoodOrder(numAnimals, avgFood) {
	
	//checks if either is NaN or if the result is negative
	if (((isNaN(numAnimals)) || (isNaN(avgFood))) || (0>numAnimals*avgFood)) {
		return -1;		
	}
	
	//displays the calculated answer in the console
	console.log("Food order = " + numAnimals * avgFood + "kg of food." );
	
	//returns the answer
	return (numAnimals * avgFood);
}

/**
 * Determines which day of the week had the most nnumber of people visiting the
 * pet store. If more than one day of the week has the same, highest amount of
 * traffic, an array containing the days (in any order) should be returned.
 * (ex. ["Wednesday", "Thursday"]). If the input is null or an empty array, the function
 * should return null.
 * @param week an array of Weekday objects
 * @return a string containing the name of the most popular day of the week if there is only one most popular day, and an array of the strings containing the names of the most popular days if there are more than one that are most popular
 */
 
 //gets the most popular days by preforming two passes over the same array
 //easier to read
function mostPopularDays(week) {
	//check for empty or null
	if (week == null || week.length == 0){
		console.log('mostPopularDays() - null or empty input')
		return null;
	}
	
	var maxTraffic = 0; //holds the most traffic in the week
	var dayList = new Array(); //list of the days that have the most traffic
	
	//loops through the week array and finds the maximum amount of traffic
	for ( var i = 0; i < week.length ; i++){
		if(maxTraffic < week[i].traffic)
			maxTraffic = week[i].traffic;
	}
	
	//loops through the week array and adds days with traffic equal to the max
	for ( var i = 0; i < week.length ; i++){
		if (maxTraffic == week[i].traffic)
			dayList.push(week[i].name);
	}
	
	//displays the days in the dayList
	for (i = 0 ; i < dayList.length ; i++){
		console.log(dayList[i]);
	}
	
	return dayList;
}

//gets the most popular days by preforming one pass over an array
function mpdOnePass(week) {
	//check for empty or null
	if (week == null || week.length == 0){
		console.log('mostPopularDays() - null or empty input')
		return null;
	}
	
	var maxTraffic = 0; //holds the most traffic in the week
	var dayList = new Array(); //list of the days that have the most traffic
	
	//loops through the week array and finds the maximum amount of traffic
	for ( var i = 0; i < week.length ; i++){
		if(maxTraffic < week[i].traffic){
			maxTraffic = week[i].traffic;
			dayList = new Array(week[i].name);
			console.log('new max day: ' + week[i].name + ' traffic: ' + week[i].traffic );
		}else if (maxTraffic == week[i].traffic){
			dayList.push(week[i].name);
			console.log('tied with max day: ' + week[i].name + ' traffic: ' + week[i].traffic );
		} 
	}
	
	//displays the days in the dayList
	for (i = 0 ; i < dayList.length ; i++){
		console.log(dayList[i]);
	}
	
	return dayList;
}

//create a list of weekdays and find the days with the most traffic
function generateDays(){
	//creates a list of weekdays with a random amount of traffic
	var weekList = [
	new Weekday("Sunday", Math.floor(Math.random() * 10) + 1),
	new Weekday("Monday", Math.floor(Math.random() * 10) + 1),
	new Weekday("Tuesday", Math.floor(Math.random() * 10) + 1),
	new Weekday("Wednesday", Math.floor(Math.random() * 10) + 1),
	new Weekday("Thursday", Math.floor(Math.random() * 10) + 1),
	new Weekday("Friday", Math.floor(Math.random() * 10) + 1),
	new Weekday("Saturday", Math.floor(Math.random() * 10) + 1)
	];
	
	//prints the weeklist in the console
	console.log(weekList);
	
	//returns the weeklist
	return weekList;
}

function test2(){
	mostPopularDays(generateDays());
	
}

function test2OnePass(){
	mPDOnePass(generateDays());
	
}
/**
 * Given three arrays of equal length containing information about a list of
 * animals - where names[i], types[i], and breeds[i] all relate to a single
 * animal - return an array of Animal objects constructed from the provided
 * info.
 * @param names the array of animal names
 * @param types the array of animal types (ex. "Dog", "Cat", "Bird")
 * @param breeds the array of animal breeds
 * @return an array of Animal objects containing the animals' information, or an
 *         empty array if the array's lengths are unequal or zero, or if any array is null.
 */
function createAnimalObjects(names, types, breeds) {
	//checks for length mismatches
	if (names.length != types.length || types.length != breeds.length){
		return null
	}
	
	//creates the array to hold the animal objects
	var animalObjectArray = [];
	
	//creates the animal objects based on the info in the arrays
	//and adds them to the animalObjectArray
	for(var i = 0 ; i < names.length ; i++){
	animalObjectArray.push( new Animal(names[i], types[i], breeds[i]));
	}
	
	return animalObjectArray;
}

function createAnimalArray(){
	//create an array to hold 3 animals
	var nameArray = [];
	var typeArray = [];
	var breedArray = [];
	var animalArray = [];
	
	//populate nameArray
	nameArray.push("Birdy");
	nameArray.push("Neko-Chan");
	nameArray.push("Inu-Chan");
	
	//populate typeArray
	typeArray.push("Bird");
	typeArray.push("Cat");
	typeArray.push("Dog");
	
	//populate breedArray
	breedArray.push("Parakeet");
	breedArray.push("Persian");
	breedArray.push("Pomeranian");

	//populate the animalArray with the other arrays
	animalArray.push(nameArray);
	animalArray.push(typeArray);
	animalArray.push(breedArray);
	
	//return the animalArray
	return animalArray;
}

function test3(){
	//get an array of arrays for names, types, and breeds
	var animalArray = createAnimalArray();
	console.log(animalArray);
	
	//creates an array to hold animal objects and passes 
	//the animal array to the create animal objects function
	var animalObjectsArray = createAnimalObjects(animalArray[0],animalArray[1],animalArray[2]);
	
	console.log(animalObjectsArray);

}

/////////////////////////////////////////////////////////////////
//
//  Do not change any code below here!
//
/////////////////////////////////////////////////////////////////


/**
 * A prototype to create Weekday objects
 */
function Weekday (name, traffic) {
    this.name = name;
    this.traffic = traffic;
}

/**
 * A prototype to create Item objects
 */
function Item (name, barcode, sellingPrice, buyingPrice) {
     this.name = name;
     this.barcode = barcode;
     this.sellingPrice = sellingPrice;
     this.buyingPrice = buyingPrice;
}
 /**
  * A prototype to create Animal objects
  */
function Animal (name, type, breed) {
    this.name = name;
     this.type = type;
     this.breed = breed;
}


/**
 * Use this function to test whether you are able to run JavaScript
 * from your browser's console.
 */
function helloworld() {
    return 'hello world!';
}

