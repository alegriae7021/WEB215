// WEB 215
// M2HW1
// Erik Alegira
// 9-21

//test function for each of the problems
function problem1(){
	//generates a random length and height to test the calcArea fn
	var l = Math.floor(Math.random() * 40) + 1;
	var w = Math.floor(Math.random() * 40) + 1;
	
	//displays the length and height
	console.log("Testing with Length: " + l + "/ height: " + w);
	
	//create the var area to hold the result of calcArea
	var area = calcArea(l,w);
	
	//displays the result
	console.log(area)
	
	
	//test output with a negative value
	console.log("Testing with Length: -10/ height: 20");
	area = calcArea( -10 , 20);
	
	//displays the result
	console.log(area)
	
	//test output with a NaN value
	console.log("Testing with Length: 10/ height: twelve");
	area = calcArea( "something" , "twelve");
	
	//displays the result
	console.log(area)
}

//Problem 1 code ------ START ------ Problem 1 code
//{
	
//calculates the area of a rectangle
function calcArea(length, height){
	//return -1 if either length or height is NaN or negative
	if (( isNaN(length) || isNaN(height) ) || ( length < 0 || height < 0 )){
		return -1;
	}
	
	//calculates the area of a rectangle
	var area = length * height;
	
	//returns the area
	return area;
}

//}
//Problem 1 code ------- end ------- Problem 1 code

function problem2(){
	console.log("comparing 3 randomly generated rectangles made with an object constructor");
	compareRectangles(genRandomRectangle(), genRandomRectangle());
	compareRectangles(genRandomRectangle(), genRandomRectangle());
	compareRectangles(genRandomRectangle(), genRandomRectangle());
	
	console.log("comparing 4 with predefined rectangles made using an object literal");
	compareRectangles(defineRectangle(10,"something"),defineRectangle(12,10));
	compareRectangles(defineRectangle(10,12),defineRectangle(12,10));
	compareRectangles(defineRectangle(12, 10),defineRectangle(8,9));
	compareRectangles(defineRectangle(7,4),defineRectangle(12,12));
}

//{Problem 2 code ------ START ------ Problem 2 code


//I wanted to do it this way because it feels better to me
//to have rectangle constructor rather than use an object literal 
//every time i wanted to make a rectangle


//rectangle object 
function rectangle(length, height) {
	this.length = length;
	this.height = height;
}

//make a randomly generated rectangle object
function genRandomRectangle(){
	//generates a rectangle with random values for length and height between 1 and 100
	var randomRect = new rectangle(( Math.floor(Math.random() * 100) + 1), (Math.floor(Math.random() * 100) + 1));
	
	return randomRect;
}

//the way stated in the directions
function defineRectangle(l, h){
	var rectangle = {
		length: l,
		height: h
	}

	return rectangle;
}


//compareRectangles method
//-1: bad data
//0: the area is the same
//1: rect1 is larger
//2: rect2 is larger
function compareRectangles(rect1, rect2){
	//calculates the areas of the two rectangles
	var area1 = calcArea(rect1.length, rect1.height);
	var area2 = calcArea(rect2.length, rect2.height);
	
	//if either area is -1 then the data is bad and
	//the answer can not be determined.
	if (area1 == -1 || area2 == -1){
		console.log("The data is bad");
		console.log("The answer can not be determined");
		return -1;
	}
	
	//display the data
	console.log("rectangle 1( Length: " + rect1.length + "/ Height: " + rect1.height + " / Area: " + area1);
	console.log("rectangle 2( Length: " + rect2.length + "/ Height: " + rect2.height + " / Area: " + area2);
	
	//if the two have the same area
	if ( area1 === area2 ){
		console.log("The two have the same area");
		return 0;
	}
	
	//if rectangle1 > rectangle2
	if ( area1 > area2 ){
		console.log("The first rectangle is larger");
		return 1;
	}
	
	//if rectangle1 < rectangle2
	if ( area1 < area2 ){
		console.log("The second rectangle is larger");
		return 2;
	}
}

//}
//Problem 2 code ------- end ------- Problem 2 code

function problem3(){
	navigation();
}

//{Problem 3 code ------ START ------ Problem 3 code

//loads directions from the courthouse to ftcc into a stack
function makeDirectionList(){
	var directions = [];
	
	directions.unshift("head northeast on dick st toward otis F. Jones Pkwy");
	directions.unshift("Turn right onto Otis F. Jones Pkwy");
	directions.unshift("Slight left onto Bow St");
	directions.unshift("Turn right onto Green St");
	directions.unshift("turn left onto Rowan St");
	directions.unshift("Rowan St turns right and becomes Bragg Blvd");
	directions.unshift("Turn left onto Barrington Cross St");
	directions.unshift("Continue onto Devers St");
	directions.unshift("Turn right onto Hull Rd");

	return directions;
	
}

function navigation(){
	var dirStack = makeDirectionList();
	var returnTrip = [];
	var nextStep;
	
	console.log("Start trip:");
	while (dirStack.length > 0){
		nextStep = dirStack.pop();
		console.log(nextStep);
		returnTrip.push(nextStep);
	}
	console.log("Destination will be on the left");
	console.log("you have arrived");
	
	
	console.log("Returning to courthouse");
	while (returnTrip.length > 0){
		nextStep = returnTrip.pop();
		console.log(nextStep);
	}
	console.log("Destination will be on the right");
	console.log("you have arrived");
	
}

//}
//Problem 3 code ------- end ------- Problem 3 code

function problem4(){
	
}

//Problem 4 code ------ START ------ Problem 4 code



//Problem 4 code ------- end ------- Problem 4 code

function problem5(){
	console.log(range(1,10));
	console.log(sum(range(1,10)));
	console.log("and one sum function using recursion");
	console.log(sumR(range(1,10)));
}

//Problem 5 code ------ START ------ Problem 5 code

/* function range(start, end){
	//catches invalid input
	if (end > start){
		console.log("Invalid input");
		return -1;	
	}
	
	var numRange = []; 
	
	for (var i = start; i < end + 1; i++){
		numRange.push(i);
	}
	
	return numRange;
	
} */

function sum(numbers){
	var total = 0;
	
	for(var i = 0; i < numbers.length ; i++){
		total = total + numbers[i];
	}
	
	return total;
}

//RECURSION!!!!!!!!!!!!!!!
function sumR(numbers){
	
	var total = 0;
	
	if (numbers.length>1){
		total = numbers.pop() + sumR(numbers);
	} else {
		total = numbers.pop();
	}

	return total;
}

//Problem 5 code ------- end ------- Problem 5 code

function problem6(){
	console.log(range(1,10));
	console.log(range(1,10,2));
	console.log(range(1,10,-2));
	console.log(range(10,2,-2));
	
	console.log(sum(range(1,10)));
	
}

//{Problem 6 code ------ START ------ Problem 6 code

//input for range should either be (start, end) or (start, end, step)
function range(){
	var numRange = []; 
	
	if (arguments.length == 2){ //if it has two arguments then it is the default range fn
		if (arguments[1] < arguments[0]){
			console.log("Invalid input");
			return -1;	
		}	
	
		for (var i = arguments[0]; i < arguments[1] + 1; i++){
			numRange.push(i);
		}
		return numRange;

	} else if (arguments.length == 3){ //if it has 3 arguments then it is the advenced range fn
		if (arguments[2] > 0 && arguments[0] < arguments[1]){
			for (var i = arguments[0]; i < arguments[1] + 1; i = i + arguments[2]){
				numRange.push(i);
			}
		} else if (arguments[2] < 0 && arguments[0] > arguments[1]){
			for (var i = arguments[0] ; i > arguments[1] - 1; i = i + arguments[2]){
				numRange.push(i);
			}
		} else if (arguments[2] == 0 ||
		(arguments[2] < 0 && arguments[0] < arguments[1]) ||
		(arguments[2] > 0 && arguments[0] > arguments[1])){ //catches infinite loops
			console.log("Invalid input/ results in infinite loop");
			return -1;
		}
	} else { //if the function does not have 2 or 3 arguments then it is invalid
		console.log("Invalid input/ wrong number of arguments");
		return -1;		
	}
	return numRange;
	
}

//}Problem 6 code ------- end ------- Problem 6 code

function problem7(){
	
}

//Problem 7 code ------ START ------ Problem 7 code



//Problem 7 code ------- end ------- Problem 7 code
